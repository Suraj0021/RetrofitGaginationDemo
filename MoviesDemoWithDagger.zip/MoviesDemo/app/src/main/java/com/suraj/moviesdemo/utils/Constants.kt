package com.suraj.moviesdemo.utils

object Constants {

const val BASE_URL="https://api.themoviedb.org/3/movie/"

}